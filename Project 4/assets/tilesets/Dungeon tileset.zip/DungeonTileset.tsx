<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.1" name="Tileset gameboy2" tilewidth="8" tileheight="8" tilecount="182" columns="14">
 <image source="D:/Rekki/Projekty/PROJEKTY GIER/Gameboy/Tileset gameboy2.png" width="112" height="104"/>
</tileset>
